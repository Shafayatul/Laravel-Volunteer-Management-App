<div class="row">
    <div class="col-md-6">
        <div class="<?php echo e($errors->has('first_name') ? 'has-error' : ''); ?>">
            <?php echo Form::label('first_name', 'First Name', ['class' => 'control-label']); ?>

            <?php echo Form::text('first_name', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('first_name', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('last_name') ? 'has-error' : ''); ?>">
            <?php echo Form::label('last_name', 'Last Name', ['class' => 'control-label']); ?>

            <?php echo Form::text('last_name', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('last_name', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('phone_number') ? 'has-error' : ''); ?>">
            <?php echo Form::label('phone_number', 'Phone Number', ['class' => 'control-label']); ?>

            <?php echo Form::text('phone_number', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('phone_number', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('provide_detail') ? 'has-error' : ''); ?>">
            <?php echo Form::label('provide_detail', 'This volunteer system may require a background check.    Will you provide details if required?', ['class' => 'control-label']); ?>

            <?php echo Form::select('provide_detail', array('Yes' => 'Yes', 'No' => 'No'), null, ['class' => 'form-control']); ?>

            <?php echo $errors->first('provide_detail', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('current_employer') ? 'has-error' : ''); ?>">
            <?php echo Form::label('current_employer', 'Current Employer', ['class' => 'control-label']); ?>

            <?php echo Form::text('current_employer', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('current_employer', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-md-6">

        <div class="<?php echo e($errors->has('years_of_experience') ? 'has-error' : ''); ?>">
            <?php echo Form::label('years_of_experience', 'Years Of Experience', ['class' => 'control-label']); ?>

            <?php echo Form::number('years_of_experience', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('years_of_experience', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('linkedin') ? 'has-error' : ''); ?>">
            <?php echo Form::label('linkedin', 'Linkedin', ['class' => 'control-label']); ?>

            <?php echo Form::text('linkedin', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('linkedin', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('instagram') ? 'has-error' : ''); ?>">
            <?php echo Form::label('instagram', 'Instagram', ['class' => 'control-label']); ?>

            <?php echo Form::text('instagram', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('instagram', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('facebook') ? 'has-error' : ''); ?>">
            <?php echo Form::label('facebook', 'Facebook', ['class' => 'control-label']); ?>

            <?php echo Form::text('facebook', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('facebook', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('twitter') ? 'has-error' : ''); ?>">
            <?php echo Form::label('twitter', 'Twitter', ['class' => 'control-label']); ?>

            <?php echo Form::text('twitter', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('twitter', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('image') ? 'has-error' : ''); ?>">
            <?php echo Form::label('image', 'Image', ['class' => 'control-label']); ?>

            <?php echo Form::file('image', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('image', '<p class="help-block">:message</p>'); ?>

        </div>
        <br>
        <?php echo Form::submit($formMode === 'edit' ? 'Update' : 'Create', ['class' => 'btn btn-primary pull-right form-margin']); ?>

    </div>
</div>