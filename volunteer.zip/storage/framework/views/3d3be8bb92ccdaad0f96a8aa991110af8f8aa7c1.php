<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>Opportunity</h2>
            </div>
            <!-- Input -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                             Opportunity Detail
                            </h2>
                        </div>
                        <?php echo $__env->make('layouts.partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <div class="body">

                            <div class="row">
                                <h3>Tilte: <?php echo e($opportunity->title); ?></h3>
                                <div class="col-sm-6">
                                    <h4>Tasks:</h4>
                                    <hr>

                                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <b>Task <?php echo e($loop->iteration); ?> </b>
                                        <br>
                                        <p>
                                            <b>Detail: </b> <?php echo e($task->description); ?>

                                        </p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="col-sm-6">
                                    <h4>All Info About This Opportunity</h4>
                                    <hr>
                                    <p>
                                        <b>date: </b> <?php echo e($opportunity->date); ?>

                                    </p>
                                    <p>
                                        <b>Time: </b> <?php echo e($opportunity->start_time); ?> - <?php echo e($opportunity->end_time); ?>

                                    </p>
                                    <p>
                                        <b>address: </b> <?php echo e($opportunity->address); ?>

                                    </p>
                                    <p>
                                        <b>contact_number: </b> <?php echo e($opportunity->contact_number); ?>

                                    </p>
                                    <p>
                                        <b>contact_name: </b> <?php echo e($opportunity->contact_name); ?>

                                    </p>
                                    <p>
                                        <b>contact_email: </b> <?php echo e($opportunity->contact_email); ?>

                                    </p>
                                    <p>
                                        <b>Limit In Volunteer: </b> 
                                        <?php if($opportunity->is_volunteer_limit==1): ?> 
                                            Yes
                                        <?php else: ?>
                                            No
                                        <?php endif; ?>
                                    </p>
                                    <p>
                                        <b>number_of_volunteer: </b> <?php echo e($opportunity->number_of_volunteer); ?>

                                    </p>
                                    <p>
                                        <b>detail: </b> <?php echo e($opportunity->detail); ?>

                                    </p>
                                    <p>
                                        <b>number_of_student: </b> <?php echo e($opportunity->number_of_student); ?>

                                    </p>
                                    <p>
                                        <b>is_call: </b> 
                                        <?php if($opportunity->is_call==1): ?> 
                                            Yes
                                        <?php else: ?>
                                            No
                                        <?php endif; ?>
                                    </p>                                    
                                    <p>
                                        <b>is_published: </b> 
                                        <?php if($opportunity->is_published==1): ?> 
                                            Published
                                        <?php else: ?>
                                            Saved
                                        <?php endif; ?>
                                    </p>
                                    <p>
                                        <b>Subjects: </b> 
                                        <?php if($opportunity->subject1==1): ?> 
                                            Subject1
                                        <?php endif; ?>
                                        <?php if($opportunity->subject2==1): ?> 
                                            Subject2
                                        <?php endif; ?>
                                        <?php if($opportunity->subject3==1): ?> 
                                            Subject3
                                        <?php endif; ?>
                                        <?php if($opportunity->subject4==1): ?> 
                                            Subject4
                                        <?php endif; ?>
                                        <?php if($opportunity->subject5==1): ?> 
                                            Subject5
                                        <?php endif; ?>
                                        <?php if($opportunity->subject6==1): ?> 
                                            Subject6
                                        <?php endif; ?>
                                        <?php if($opportunity->subject7==1): ?> 
                                            Subject7
                                        <?php endif; ?>
                                        <?php if($opportunity->subject8==1): ?> 
                                            Subject8
                                        <?php endif; ?>

                                    </p>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Input -->
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>