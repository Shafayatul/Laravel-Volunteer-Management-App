<?php $__env->startSection('content'); ?>

<style type="text/css">
	input.transparent-input{
	   background-color:rgba(0,0,0,0) !important;
	   /*border:none !important;*/
	   border-radius: 0 !important;
	}

	.transparent-input { 
	color: #fff; 
	}
	.transparent-input:focus{ 
	color: #fff; 
	}
	.transparent-input::placeholder { /* Chrome, Firefox, Opera, Safari 10.1+ */
	    color: #fff;
	    opacity: 1; /* Firefox */
	}

	.transparent-input:-ms-input-placeholder { /* Internet Explorer 10-11 */
	    color: #fff;
	}

	.transparent-input::-ms-input-placeholder { /* Microsoft Edge */
	    color: #fff;
	}
	.btn-bottom-right{
		position: absolute;
		right:    0;
		bottom:   0;
	}
	.class-list{
		border: 4px dotted white;
		padding: 5px;
	}
</style>

    <header class="masthead text-white">
      <div class="masthead-content">
        <div class="container">
        	<h3 class="masthead-subheading mb-0 text-center" style="font-size: 40px;">Teacher Registration Form</h3>
        	<br>

        	<div class="row">
        		<div class="col-md-8  mx-auto">
        			<?php echo Form::open(['url' => url('/teacher/signup'), 'files' => true]); ?>

					<div class="row" style="background: rgba(0, 0, 0, 0.56);padding: 3em; min-height: 426px;">
						<div class="col-md-12">
							<h3 class="text-center">Register</h3>
							Thanks for registering your class with us. Please complete the information below. You will receive a confirmation email shortly.
							<br>
							<br>
						</div>
						
					    <div class="col-sm-6">
					        <div class="<?php echo e($errors->has('first_name') ? 'has-error' : ''); ?>">
					            <?php echo Form::text('first_name', null, ('required' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'First Name*'] : ['class' => 'form-control transparent-input', 'placeholder' => 'First Name*']); ?>

					            <?php echo $errors->first('first_name', '<p class="help-block">:message</p>'); ?>

					        </div>
					        <br>
					        <div class="<?php echo e($errors->has('last_name') ? 'has-error' : ''); ?>">
					            <?php echo Form::text('last_name', null, ('' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'Last Name'] : ['class' => 'form-control transparent-input', 'placeholder' => 'Last Name']); ?>

					            <?php echo $errors->first('last_name', '<p class="help-block">:message</p>'); ?>

					        </div>
					        <br>
					        <div class="<?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
					            <?php echo Form::email('email', null, ('required' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'Email'] : ['class' => 'form-control transparent-input', 'placeholder' => 'Email']); ?>

					            <?php echo $errors->first('password', '<p class="help-block">:message</p>'); ?>

					        </div>
					        <br>
					        <div class="<?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
					            <?php echo Form::text('password', null, ('required' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'Password*'] : ['class' => 'form-control transparent-input', 'placeholder' => 'Password*']); ?>

					            <?php echo $errors->first('password', '<p class="help-block">:message</p>'); ?>

					        </div>
					        <br>
					        <div class="<?php echo e($errors->has('phone_number') ? 'has-error' : ''); ?>">
					            <?php echo Form::text('phone_number', null, ('' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'Phone Number'] : ['class' => 'form-control transparent-input', 'placeholder' => 'Phone Number']); ?>

					            <?php echo $errors->first('phone_number', '<p class="help-block">:message</p>'); ?>

					        </div>
					        <br>
					        <div class="<?php echo e($errors->has('school_name') ? 'has-error' : ''); ?>">
					            <?php echo Form::text('school_name', null, ('' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'School Name'] : ['class' => 'form-control transparent-input', 'placeholder' => 'School Name']); ?>

					            <?php echo $errors->first('school_name', '<p class="help-block">:message</p>'); ?>

					        </div>
					        <br>
			        		<div class="<?php echo e($errors->has('image') ? 'has-error' : ''); ?>">
			        			<p>Upload Profile Image:</p>
			        			<?php echo Form::file('image', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

			        		</div> 
					    </div>
					    <div class="col-sm-6">


					    	<div class="class-list">
					    		<br>
						    	<h6 class="text-center">List Classes You Manage:</h6>
						    	<hr>
						        <div class="<?php echo e($errors->has('class_one') ? 'has-error' : ''); ?>">
						            <?php echo Form::text('class_one', null, ('' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'Class Period, Week Day, Time:'] : ['class' => 'form-control transparent-input', 'placeholder' => 'Class Period, Week Day, Time:']); ?>

						            <?php echo $errors->first('class_one', '<p class="help-block">:message</p>'); ?>

						        </div>
						        <br>

						        <div class="<?php echo e($errors->has('class_two') ? 'has-error' : ''); ?>">
						            <?php echo Form::text('class_two', null, ('' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'Class Period, Week Day, Time:'] : ['class' => 'form-control transparent-input', 'placeholder' => 'Class Period, Week Day, Time:']); ?>

						            <?php echo $errors->first('class_two', '<p class="help-block">:message</p>'); ?>

						        </div>
						        <br>

						        <div class="<?php echo e($errors->has('class_three') ? 'has-error' : ''); ?>">
						            <?php echo Form::text('class_three', null, ('' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'Class Period, Week Day, Time:'] : ['class' => 'form-control transparent-input', 'placeholder' => 'Class Period, Week Day, Time:']); ?>

						            <?php echo $errors->first('class_three', '<p class="help-block">:message</p>'); ?>

						        </div>
						        <br>

					    	</div>

					        <?php echo Form::submit('Register', ['class' => 'btn btn-secondary btn-bottom-right']); ?>

					    </div>
					    
					</div>
					<?php echo Form::close(); ?>

        		</div>
        	</div>




        </div>
      </div>
      <div class="bg-circle-1 bg-circle"></div>
      <div class="bg-circle-2 bg-circle"></div>
      <div class="bg-circle-3 bg-circle"></div>
      <div class="bg-circle-4 bg-circle"></div>
    </header>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>