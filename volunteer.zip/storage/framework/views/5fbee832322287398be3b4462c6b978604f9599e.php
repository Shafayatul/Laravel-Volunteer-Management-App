<div class="row">
    <div class="col-md-6">
        <div class="<?php echo e($errors->has('first_name') ? 'has-error' : ''); ?>">
            <?php echo Form::label('first_name', 'First Name', ['class' => 'control-label']); ?>

            <?php echo Form::text('first_name', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('first_name', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('last_name') ? 'has-error' : ''); ?>">
            <?php echo Form::label('last_name', 'Last Name', ['class' => 'control-label']); ?>

            <?php echo Form::text('last_name', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('last_name', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
            <?php echo Form::label('email', 'Email', ['class' => 'control-label']); ?>

            <?php echo Form::email('email', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('password', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
            <?php echo Form::label('password', 'Password', ['class' => 'control-label']); ?>

            <?php echo Form::text('password', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('password', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('phone_number') ? 'has-error' : ''); ?>">
            <?php echo Form::label('phone_number', 'Phone Number', ['class' => 'control-label']); ?>

            <?php echo Form::text('phone_number', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('phone_number', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-md-6">
        <div class="<?php echo e($errors->has('school_name') ? 'has-error' : ''); ?>">
            <?php echo Form::label('school_name', 'School Name', ['class' => 'control-label']); ?>

            <?php echo Form::text('school_name', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('school_name', '<p class="help-block">:message</p>'); ?>

        </div>

        <div class="<?php echo e($errors->has('class_one') ? 'has-error' : ''); ?>">
            <?php echo Form::label('class_one', 'Class Period, Week Day, Time:', ['class' => 'control-label']); ?>

            <?php echo Form::text('class_one', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('class_one', '<p class="help-block">:message</p>'); ?>

        </div>


        <div class="<?php echo e($errors->has('class_two') ? 'has-error' : ''); ?>">
            <?php echo Form::label('class_two', 'Class Period, Week Day, Time:', ['class' => 'control-label']); ?>

            <?php echo Form::text('class_two', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('class_two', '<p class="help-block">:message</p>'); ?>

        </div>


        <div class="<?php echo e($errors->has('class_three') ? 'has-error' : ''); ?>">
            <?php echo Form::label('class_three', 'Class Period, Week Day, Time:', ['class' => 'control-label']); ?>

            <?php echo Form::text('class_three', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('class_three', '<p class="help-block">:message</p>'); ?>

        </div>

        <br>
        <br>

        <?php echo Form::submit($formMode === 'edit' ? 'Update' : 'Create', ['class' => 'btn btn-primary form-marign pull-right']); ?>

    </div>
</div>