<?php echo e(Form::label('name', 'Name:')); ?>

<?php echo e(Form::text('name', null, array("class" => "form-control", "required" => "required", "maxlength" => "191"))); ?>

<?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary form-margin']); ?>