<?php $__env->startSection('content'); ?>

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>Roles</h2>
            </div>
            <div class="row">
                <div class="col-md-12">
                     <?php if(Session::has('flash_message')): ?>
                        <div class="alert alert-success">
                            <strong>Success!</strong> <?php echo e(Session::get('flash_message')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(Session::has('error')): ?>
                    <div class="alert alert-danger">
                        <strong>Error!</strong> <?php echo e(Session::get('error')); ?>

                    </div>
                    <?php endif; ?>   

                    <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                        <strong>Error!</strong> 
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>


                </div>
            </div>
            <div class="row clearfix">
                <!-- Task Info -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-hover dashboard-task-infos">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(isset($loop->iteration) ? $loop->iteration : $item->id); ?></td>
                                                <td><?php echo e($item->name); ?></td>
                                                <td>
                                                    <a href="<?php echo e(url('/admin/role/' . $item->id . '/edit')); ?>" title="Edit role"><button class="btn btn-primary btn-sm"><i class="material-icons">mode_edit</i></button></a>
                                                    <?php echo Form::open([
                                                        'method'=>'DELETE',
                                                        'url' => ['/admin/role', $item->id],
                                                        'style' => 'display:inline'
                                                        ]); ?>

                                                    <?php echo Form::button('<i class="material-icons">delete</i>', array(
                                                        'type' => 'submit',
                                                        'class' => 'btn btn-danger btn-sm',
                                                        'title' => 'Delete role',
                                                        'onclick'=>'return confirm("Confirm delete?")'
                                                        )); ?>

                                                        <?php echo Form::close(); ?>

                                                    </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>                        
                        </div>
                    </div>
                </div>
                <!-- #END# Task Info -->
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>