<div class="<?php echo e($errors->has('old_password') ? 'has-error' : ''); ?>">
    <?php echo Form::label('old_password', 'Old Password', ['class' => 'control-label']); ?>

    <?php echo Form::text('old_password', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('old_password', '<p class="help-block">:message</p>'); ?>

</div>
<div class="<?php echo e($errors->has('new_password') ? 'has-error' : ''); ?>">
    <?php echo Form::label('new_password', 'New Password', ['class' => 'control-label']); ?>

    <?php echo Form::text('new_password', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('new_password', '<p class="help-block">:message</p>'); ?>

</div>
<div class="<?php echo e($errors->has('confirm_password') ? 'has-error' : ''); ?>">
    <?php echo Form::label('confirm_password', 'Confirm Password', ['class' => 'control-label']); ?>

    <?php echo Form::text('confirm_password', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('confirm_password', '<p class="help-block">:message</p>'); ?>

</div>

    <?php echo Form::submit($formMode === 'edit' ? 'Update' : 'Create', ['class' => 'btn btn-primary form-margin']); ?>

