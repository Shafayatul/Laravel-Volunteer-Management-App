<?php $__env->startSection('content'); ?>

<style type="text/css">
	input.transparent-input{
	   background-color:rgba(0,0,0,0) !important;
	   /*border:none !important;*/
	   border-radius: 0 !important;
	}

	.transparent-input { 
	color: #fff; 
	}
	.transparent-input:focus{ 
	color: #fff; 
	}
	.transparent-input::placeholder { /* Chrome, Firefox, Opera, Safari 10.1+ */
	    color: #fff;
	    opacity: 1; /* Firefox */
	}

	.transparent-input:-ms-input-placeholder { /* Internet Explorer 10-11 */
	    color: #fff;
	}

	.transparent-input::-ms-input-placeholder { /* Microsoft Edge */
	    color: #fff;
	}
	.btn-bottom-right{
		position: absolute;
		right:    0;
		bottom:   0;
	}
	.class-list{
		border: 4px dotted white;
		padding: 5px;
	}
</style>

    <header class="masthead text-white">
      <div class="masthead-content">
        <div class="container">
        	<h3 class="masthead-subheading mb-0 text-center" style="font-size: 40px;">Volunteer Registration Form</h3>
        	<br>

        	<div class="row">
        		<div class="col-md-8  mx-auto">
        			<?php echo Form::open(['url' => url('/volunteer/signup'), 'files' => true]); ?>

					<div class="row" style="background: rgba(0, 0, 0, 0.56);padding: 3em; min-height: 426px;">
						<div class="col-md-12">
							<h3 class="text-center">Register</h3>
							Thanks for registering your class with us. Please complete the information below. You will receive a confirmation email shortly.
							<br>
							<br>
						</div>
						
					    <div class="col-sm-6">
					        <div class="<?php echo e($errors->has('first_name') ? 'has-error' : ''); ?>">
					            <?php echo Form::text('first_name', null, ('required' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'First Name*'] : ['class' => 'form-control transparent-input', 'placeholder' => 'First Name*']); ?>

					            <?php echo $errors->first('first_name', '<p class="help-block">:message</p>'); ?>

					        </div>
					        <br>
					        <div class="<?php echo e($errors->has('last_name') ? 'has-error' : ''); ?>">
					            <?php echo Form::text('last_name', null, ('' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'Last Name'] : ['class' => 'form-control transparent-input', 'placeholder' => 'Last Name']); ?>

					            <?php echo $errors->first('last_name', '<p class="help-block">:message</p>'); ?>

					        </div>
					        <br>
					        <div class="<?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
					            <?php echo Form::email('email', null, ('required' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'Email'] : ['class' => 'form-control transparent-input', 'placeholder' => 'Email']); ?>

					            <?php echo $errors->first('password', '<p class="help-block">:message</p>'); ?>

					        </div>
					        <br>
					        <div class="<?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
					            <?php echo Form::text('password', null, ('required' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'Password*'] : ['class' => 'form-control transparent-input', 'placeholder' => 'Password*']); ?>

					            <?php echo $errors->first('password', '<p class="help-block">:message</p>'); ?>

					        </div>
					        <br>
					        <div class="<?php echo e($errors->has('phone_number') ? 'has-error' : ''); ?>">
					            <?php echo Form::text('phone_number', null, ('' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'Phone Number'] : ['class' => 'form-control transparent-input', 'placeholder' => 'Phone Number']); ?>

					            <?php echo $errors->first('phone_number', '<p class="help-block">:message</p>'); ?>

					        </div>
					        <br>
					        <div class="<?php echo e($errors->has('current_employer') ? 'has-error' : ''); ?>">
					            <?php echo Form::text('current_employer', null, ('' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'Current employer'] : ['class' => 'form-control transparent-input', 'placeholder' => 'Current employer']); ?>

					            <?php echo $errors->first('current_employer', '<p class="help-block">:message</p>'); ?>

					        </div>
					        <br>
					        <div class="<?php echo e($errors->has('years_of_experience	') ? 'has-error' : ''); ?>">
					            <?php echo Form::text('years_of_experience	', null, ('' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'Years Of Experience'] : ['class' => 'form-control transparent-input', 'placeholder' => 'Years Of Experience']); ?>

					            <?php echo $errors->first('years_of_experience	', '<p class="help-block">:message</p>'); ?>

					        </div>
					        <br>

					        <div class="<?php echo e($errors->has('provide_detail') ? 'has-error' : ''); ?>">
					        	<p>This volunteer system may require a background check. Will you provide details if required? </p>
					            <?php echo Form::select('provide_detail', array('Yes' => 'Yes', 'No' => 'No'), null, ['class' => 'form-control']); ?>

					            <?php echo $errors->first('provide_detail', '<p class="help-block">:message</p>'); ?>

					        </div>
					    </div>
					    <div class="col-sm-6">


					    	<div class="class-list">
					    		<br>
						    	<h6 class="text-center">Social Media Handles:</h6>
						    	<hr>
						        <div class="<?php echo e($errors->has('linkedin') ? 'has-error' : ''); ?>">
						            <?php echo Form::text('linkedin', null, ('' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'Linkedin'] : ['class' => 'form-control transparent-input', 'placeholder' => 'Linkedin']); ?>

						            <?php echo $errors->first('linkedin', '<p class="help-block">:message</p>'); ?>

						        </div>
						        <br>

						        <div class="<?php echo e($errors->has('instagram') ? 'has-error' : ''); ?>">
						            <?php echo Form::text('instagram', null, ('' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'Instagram'] : ['class' => 'form-control transparent-input', 'placeholder' => 'Instagram']); ?>

						            <?php echo $errors->first('instagram', '<p class="help-block">:message</p>'); ?>

						        </div>
						        <br>

						        <div class="<?php echo e($errors->has('facebook') ? 'has-error' : ''); ?>">
						            <?php echo Form::text('facebook', null, ('' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'Facebook'] : ['class' => 'form-control transparent-input', 'placeholder' => 'Facebook']); ?>

						            <?php echo $errors->first('facebook', '<p class="help-block">:message</p>'); ?>

						        </div>
						        <br>
						        <div class="<?php echo e($errors->has('twitter') ? 'has-error' : ''); ?>">
						            <?php echo Form::text('twitter', null, ('' == 'required') ? ['class' => 'form-control transparent-input', 'required' => 'required', 'placeholder' => 'Twitter'] : ['class' => 'form-control transparent-input', 'placeholder' => 'Twitter']); ?>

						            <?php echo $errors->first('twitter', '<p class="help-block">:message</p>'); ?>

						        </div>
						        <br>

					    	</div>
					    	<br>
					    	<br>
			        		<div class="<?php echo e($errors->has('image') ? 'has-error' : ''); ?>">
			        			<p>Upload Profile Image:</p>
			        			<?php echo Form::file('image', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

			        		</div>
					        
					        <?php echo Form::submit('Register', ['class' => 'btn btn-secondary btn-bottom-right']); ?>

					    </div>
					    
					</div>
					<?php echo Form::close(); ?>

        		</div>
        	</div>




        </div>
      </div>
      <div class="bg-circle-1 bg-circle"></div>
      <div class="bg-circle-2 bg-circle"></div>
      <div class="bg-circle-3 bg-circle"></div>
      <div class="bg-circle-4 bg-circle"></div>
    </header>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>