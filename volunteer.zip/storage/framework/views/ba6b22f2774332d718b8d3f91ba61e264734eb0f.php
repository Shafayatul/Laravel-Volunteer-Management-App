


<div class="row">
    <div class="col-sm-6">
        <div class="<?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
            <?php echo Form::label('title', 'Title', ['class' => 'control-label']); ?>

            <?php echo Form::text('title', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('title', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('date') ? 'has-error' : ''); ?>">
            <?php echo Form::label('date', 'Date', ['class' => 'control-label']); ?>

            <?php echo Form::date('date', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('date', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('start_time') ? 'has-error' : ''); ?>">
            <?php echo Form::label('start_time', 'Start Time', ['class' => 'control-label']); ?>

            <?php echo Form::text('start_time', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('start_time', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('end_time') ? 'has-error' : ''); ?>">
            <?php echo Form::label('end_time', 'End Time', ['class' => 'control-label']); ?>

            <?php echo Form::text('end_time', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('end_time', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
            <?php echo Form::label('address', 'Address', ['class' => 'control-label']); ?>

            <?php echo Form::textarea('address', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('address', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('contact_number') ? 'has-error' : ''); ?>">
            <?php echo Form::label('contact_number', 'Contact Number', ['class' => 'control-label']); ?>

            <?php echo Form::text('contact_number', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('contact_number', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('contact_name') ? 'has-error' : ''); ?>">
            <?php echo Form::label('contact_name', 'Contact Name', ['class' => 'control-label']); ?>

            <?php echo Form::text('contact_name', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('contact_name', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-sm-6">

        <h6 class="text-center">Please Enter All Details and Do Not Forget to SAVE</h6>
        <br>

        <div class="<?php echo e($errors->has('contact_email') ? 'has-error' : ''); ?>">
            <?php echo Form::label('contact_email', 'Contact Email', ['class' => 'control-label']); ?>

            <?php echo Form::text('contact_email', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('contact_email', '<p class="help-block">:message</p>'); ?>

        </div>


        <br>
        <div class="<?php echo e($errors->has('is_volunteer_limit') ? 'has-error' : ''); ?>">
            <p><b>Is there a Vol Limit ?</b></p>
            <?php echo e(Form::checkbox('is_volunteer_limit', 1, false, ['class' => 'filled-in chk-col-deep-orange', 'id' => 'is_volunteer_limit'])); ?>

            <?php echo e(Form::label("is_volunteer_limit", "Only a fixed # of people can participate in this opportunity.")); ?><br>
        </div>
        <div class="<?php echo e($errors->has('number_of_volunteer') ? 'has-error' : ''); ?>">
            <?php echo Form::label('number_of_volunteer', 'Number Of Volunteer', ['class' => 'control-label']); ?>

            <?php echo Form::number('number_of_volunteer', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('number_of_volunteer', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('detail') ? 'has-error' : ''); ?>">
            <?php echo Form::label('detail', 'Detail', ['class' => 'control-label']); ?>

            <?php echo Form::textarea('detail', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('detail', '<p class="help-block">:message</p>'); ?>

        </div>
        <div class="<?php echo e($errors->has('number_of_student') ? 'has-error' : ''); ?>">
            <?php echo Form::label('number_of_student', 'Number Of Student', ['class' => 'control-label']); ?>

            <?php echo Form::number('number_of_student', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('number_of_student', '<p class="help-block">:message</p>'); ?>

        </div>

        <br>
        <div class="<?php echo e($errors->has('is_call') ? 'has-error' : ''); ?>">
            <?php echo e(Form::checkbox('is_call', 1, false, ['class' => 'filled-in chk-col-deep-orange', 'id' => 'is_call'])); ?>

            <?php echo e(Form::label("is_call", "Volunteer Should Call for Details:")); ?>

        </div>
    </div>
</div>



<br>
<br>
<h4>Opportunity Subject Area(s):</h4>
<hr>
<div class="row">
    <div class="col-sm-3">
        <?php echo e(Form::checkbox('subject1', 1, false, ['class' => 'filled-in chk-col-deep-orange', 'id' => 'subject1'])); ?>

        <?php echo e(Form::label("subject1", ucfirst("subject1"))); ?><br>
    </div>
    <div class="col-sm-3">
        <?php echo e(Form::checkbox('subject2', 1, false, ['class' => 'filled-in chk-col-deep-orange', 'id' => 'subject2'])); ?>

        <?php echo e(Form::label("subject2", ucfirst("subject2"))); ?><br>
    </div>
    <div class="col-sm-3">
        <?php echo e(Form::checkbox('subject3', 1, false, ['class' => 'filled-in chk-col-deep-orange', 'id' => 'subject3'])); ?>

        <?php echo e(Form::label("subject3", ucfirst("subject3"))); ?><br>
    </div>
    <div class="col-sm-3">
        <?php echo e(Form::checkbox('subject4', 1, false, ['class' => 'filled-in chk-col-deep-orange', 'id' => 'subject4'])); ?>

        <?php echo e(Form::label("subject4", ucfirst("subject4"))); ?><br>
    </div>
</div>
<div class="row">
    <div class="col-sm-3">
        <?php echo e(Form::checkbox('subject5', 1, false, ['class' => 'filled-in chk-col-deep-orange', 'id' => 'subject5'])); ?>

        <?php echo e(Form::label("subject5", ucfirst("subject5"))); ?><br>
    </div>
    <div class="col-sm-3">
        <?php echo e(Form::checkbox('subject6', 1, false, ['class' => 'filled-in chk-col-deep-orange', 'id' => 'subject6'])); ?>

        <?php echo e(Form::label("subject6", ucfirst("subject6"))); ?><br>
    </div>
    <div class="col-sm-3">
        <?php echo e(Form::checkbox('subject7', 1, false, ['class' => 'filled-in chk-col-deep-orange', 'id' => 'subject7'])); ?>

        <?php echo e(Form::label("subject7", ucfirst("subject7"))); ?><br>
    </div>
    <div class="col-sm-3">
        <?php echo e(Form::checkbox('subject8', 1, false, ['class' => 'filled-in chk-col-deep-orange', 'id' => 'subject8'])); ?>

        <?php echo e(Form::label("subject8", ucfirst("subject8"))); ?><br>
    </div>
</div>

<br>
<br>
<h4>Task:</h4>
<hr>
<div class="row" id="task-div">
    <div class="col-sm-12">
        <?php echo Form::text('tasks[]', null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Task-1 Description']); ?>

    </div>
</div>

<div class="row">
    <div class="col-sm-4 col-sm-offset-4">
        <button type="button" class="btn bg-red btn-block btn-lg waves-effect" id="add-more-task">Add More task</button>
    </div>
</div>

<?php echo Form::hidden('is_published', '0'); ?>

<div class="row">
    <div class="col-sm-12 text-right">
        <button type="button" class="btn btn-primary btn-lg submit-opportunity" id="0">SAVE Opportunity</button>
        <button type="button" class="btn btn-primary btn-lg submit-opportunity" id="1">POST Opportunity</button>
    </div>
</div>