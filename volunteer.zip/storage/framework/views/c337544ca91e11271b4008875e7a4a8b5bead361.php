<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>Profile</h2>
            </div>
            <!-- Input -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                My Profile
                            </h2>
                        </div>
                        <?php echo $__env->make('layouts.partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <div class="body">
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <?php if($volunteer->image != ""): ?>
                                               <img src="<?php echo e(url('/uploads/'.$volunteer->image)); ?>" class="img-thumbnail">
                                            <?php else: ?>
                                                <img src="<?php echo e(url('/images/user.png')); ?>" class="img-thumbnail">
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-8">
                                            <h4><?php echo e($user->name); ?></h4>
                                            <p><b>Email:</b> <?php echo e($user->email); ?></p>
                                            <p><b>Volunteer Since:</b> <?php echo e(date('Y', strtotime($user->created_at))); ?></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <p><b>Phone:</b> <?php echo e($volunteer->phone_number); ?></p>
                                            <p><b>Detail:</b> <?php echo e($volunteer->provide_detail); ?></p>
                                            <p><b>Current Employer:</b> <?php echo e($volunteer->current_employer); ?></p>
                                            <p><b>Years Of Experience:</b> <?php echo e($volunteer->years_of_experience); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Input -->
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>